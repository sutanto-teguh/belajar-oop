<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
</head>

<body>
    <h1>Product List</h1>
    <a href="index.php?action=create">Create New Product</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nama Product</th>
            <th>Harga</th>
            <th>Actions</th>
        </tr>
        <?php foreach($products as $product): ?>
        <tr>
            <td><?php echo $product['id']; ?></td>
            <td><?php echo $product['nama_product']; ?></td>
            <td><?php echo $product['harga_product']; ?></td>
            <td>
                <a href="index.php?action=edit&id=<?php echo $product['id']; ?>">Edit</a>
                <a href="index.php?action=delete&id=<?php echo $product['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>