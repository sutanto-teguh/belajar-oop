<!DOCTYPE html>
<html>
<head>
    <title>Create Product</title>
</head>
<body>
    <h1>Create Product</h1>
    <form action="index.php?action=create" method="post">
        <label for="nama_product">Nama Product:</label>
        <input type="text" name="nama_product" id="nama_product" required>
        <br>
        <label for="harga">Harga:</label>
        <input type="number" name="harga_product" id="harga_product" required>
        <br>
        <input type="submit" value="create">
    </form>
</body>
</html>